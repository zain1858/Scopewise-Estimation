# Laravel Project

## Installation

```bash
git clone REPOSITORY_URL
cd project

composer install
cp .env.example .env
php artisan key:generate

php artisan migrate

npm install
npm run build

php artisan serve
```
